from individuo import Individuo
import random

class Poblacion:
    def __init__(self, size, cursos, salones, docentes, relacion_docente_curso, horarios_disponibles):
        self.size = size
        self.cursos = cursos
        self.salones = salones
        self.docentes = docentes
        self.relacion_docente_curso = relacion_docente_curso
        self.horarios_disponibles = horarios_disponibles
        self.individuos = [
            Individuo(cursos, salones, docentes, relacion_docente_curso, horarios_disponibles)
            for _ in range(size)
        ]
        self.mejor_individuo = min(self.individuos, key=lambda ind: ind.aptitud)

    def evolucionar(self, generaciones=1):
        for _ in range(generaciones):
            nueva_poblacion = []

            # Elitismo: conservar el mejor individuo
            elite = min(self.individuos, key=lambda ind: ind.aptitud)
            nueva_poblacion.append(elite)

            while len(nueva_poblacion) < self.size:
                padre = random.choice(self.individuos)
                hijo = Individuo(
                    self.cursos,
                    self.salones,
                    self.docentes,
                    self.relacion_docente_curso,
                    self.horarios_disponibles
                )
                nueva_poblacion.append(hijo)

            self.individuos = nueva_poblacion
            self.mejor_individuo = min(self.individuos, key=lambda ind: ind.aptitud)
