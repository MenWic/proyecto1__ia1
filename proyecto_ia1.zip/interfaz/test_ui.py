# test_ui.py
from PyQt5.QtWidgets import QApplication, QLabel

app = QApplication([])
label = QLabel("¡PyQt5 está funcionando!")
label.show()
app.exec_()
